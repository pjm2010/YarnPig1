package acadgild_Task1;

/*Que- 1) Write a java code with the class named �acad� and a method �main�. Hard Code the program
with two integers and print the sum of those two. */

public class acad {

	public static void main(String[] args) {
		
//Taking two integers		
		int a = 10;
		int b = 20;

//Sum of these two Numbers
	 int sum ;
	 
	sum = a+b ;	

//Printing the Sum
	
	System.out.println(sum);
	
	}

}
